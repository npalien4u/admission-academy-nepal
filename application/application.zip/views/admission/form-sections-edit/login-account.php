<div class="kt-separator kt-separator--border-dashed kt-separator--space-lg"></div>
<div class="kt-section kt-section--last">
	<div class="kt-section__body">
		<h3 class="kt-section__title kt-section__title-lg">Account Registration:</h3>
		<div class="form-group row">
			<label class="col-3 col-form-label">Username</label>
			<div class="col-9">
				<div class="input-group">
					
					<input name="username" type="text" class="form-control" value="" placeholder="Username *" aria-describedby="basic-addon1">
				</div>
				<span class="form-text text-muted"></span>
			</div>
		</div>
		<div class="form-group row">
			<label class="col-3 col-form-label">Password</label>
			<div class="col-9">
				<div class="input-group">
					
					<input id="password" name="password" type="password" class="form-control" value="" placeholder="Password *" aria-describedby="basic-addon1">
				</div>
				<span class="form-text text-muted"></span>
			</div>
		</div>
		<div class="form-group row">
			<label class="col-3 col-form-label">Confirm password</label>
			<div class="col-9">
				<div class="input-group">
					
					<input name="confirm_password" type="password" type="text" class="form-control" value="" placeholder="Confirm password *" aria-describedby="basic-addon1">
				</div>
				<span class="form-text text-muted"></span>
			</div>
		</div>
	</div>
</div>