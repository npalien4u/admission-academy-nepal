<div class="kt-section kt-section--first">
	<div class="kt-section__body">
		<div class="form-group form-group row">
			<label class="col-12 col-form-label">Thank you for your kind interest for pursuing your further study in Laboratory Boarding Secondary School (Academic Year 2079/2070). Choosing this school is one of the most important decisions, a student will make after SEE graduation. We consider your decision as a pride and sincerely work to accelerate expectations and dreams you and your parents have.</label>
		</div>
	</div>
</div>

<div class="kt-section">
	<div class="kt-section__body">
		<h3 class="kt-section__title kt-section__title-lg">Student Info:</h3>


		<div class="form-group row">

			<label class="col-3 col-form-label">Name</label>
			<div class="col-9 form-group-sub">
				<input name="first_name" class="form-control" type="text" value="" placeholder="Student Name">
			</div>

		</div>



	</div>
</div>