<div class="form-group form-group row">
	<label class="col-12 col-form-label">Please briefly mention your interest in extracurricular/co-curricular activities</label>
	
	<div class="col-12">
		<div class="input-group">
			<textarea name="interests" type="text" class="form-control" placeholder="Games/Sports/Other interests"></textarea>
		</div>
		
	</div>
</div>