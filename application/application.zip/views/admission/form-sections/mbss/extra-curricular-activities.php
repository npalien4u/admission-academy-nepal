<div class="form-group form-group row">
	<label class="col-3 col-form-label">Extra Curricular Activities</label>
	<div class="col-9">
		<div class="input-group">
			<textarea name="interests" type="text" class="form-control" placeholder="Mention the extra activities you are instersted in"></textarea>									
		</div>
		<span class="form-text text-muted">Mention the extra activities you are instersted in</span>
	</div>
	
</div>

<div class="form-group  row">	
	<label class="col-6 col-form-label">Do you want to take special ECA class beside regular classes?</label>
	<div class="col-3 ">	
		<div class="kt-radio-inline">
			<label class="kt-radio">
				<input type="radio" name="take_eca_class" value="1"> Yes
				<span></span>
			</label>
			<label class="kt-radio">
				<input type="radio" name="take_eca_class" value="0"> No
				<span></span>
			</label>		
		</div>		
	</div>
</div>

