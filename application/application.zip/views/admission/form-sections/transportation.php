<div class="form-group  row">
	
	<label class="col-3 col-form-label">Need Transportation?</label>
	<div class="col-9">		
					
		<div class="kt-radio-inline">
			<label class="kt-radio">
				<input type="radio" name="radio2"> Yes
				<span></span>
			</label>
			<label class="kt-radio">
				<input type="radio" name="radio2"> No
				<span></span>
			</label>
		
		</div>
		
		<div class="form-group input-group row">
			<label class="col-12 col-md-3 col-form-label">Pickup Location</label>
			<div class="col-9 col-md-6">
				<input  name="bus_stop_pick" type="text" class="form-control" placeholder="Pickup station for transportation" >									
			</div>
		</div>	
	
		<div class="form-group-last input-group row">
			<label class="col-12 col-md-3 col-form-label">Drop Location</label>
			<div class="col-9 col-md-6">
				<input  name="bus_stop_drop" type="text" class="form-control" placeholder="Drop station for transportation" >									
			</div>
		</div>
					
		
	</div>



</div>
