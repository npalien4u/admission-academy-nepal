<div class="form-group form-group row">
	<label class="col-3 col-form-label">Expectation</label>
	<div class="col-9">
		<div class="input-group">
			<textarea name="expectation" type="text" class="form-control" placeholder=""></textarea>									
		</div>
		<span class="form-text text-muted">Mention your expectation from this college</span>
	</div>
	
</div>
