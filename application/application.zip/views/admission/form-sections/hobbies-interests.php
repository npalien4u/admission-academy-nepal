<div class="form-group form-group row">
	<label class="col-3 col-form-label">Hobbies & Intersts</label>
	<div class="col-4">
		<div class="input-group">
			<textarea name="hobbies" type="text" class="form-control" placeholder="Hobbies"></textarea>									
		</div>
		<span class="form-text text-muted">Hobbies</span>
	</div>
	<div class="col-5">
		<div class="input-group">
			<textarea name="interests" type="text" class="form-control" placeholder="Games/Sports/Other interests"></textarea>									
		</div>
		<span class="form-text text-muted">Games/Sports/Other interests</span>
	</div>
</div>
