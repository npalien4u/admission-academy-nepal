<div class="form-group form-group row">
	<label class="col-3 col-form-label">Extra Curricular Activities</label>
	<div class="col-9">
		<div class="input-group">
			<textarea name="interests" type="text" class="form-control" placeholder="Mention the extra activities you are instersted in"></textarea>									
		</div>
		<span class="form-text text-muted">Mention the extra activities you are instersted in</span>
	</div>
	
</div>
