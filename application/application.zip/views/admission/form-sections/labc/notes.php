<div class="kt-section  kt-section--last">
	<div class="kt-section__body">
	<h3 class="kt-section__title kt-section__title-lg">Note:</h3>
		<div class="form-group row">			
			<div class="col-12">				
				<div class="kt-portlet- kt-portlet--skin-solid kt-portlet-- kt-bg-brand-">				
					<div class="kt-portlet__body-">
                    Thank You For Your Enquiry ! The College will Make Contact With You As Soon As Possible.
					</div>
				</div>
				
			</div>				
		</div>
	</div>
</div>
