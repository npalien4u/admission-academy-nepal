
<div class="form-group form-group row">
	<label class="col-3 col-form-label">Photo/Documents</label>
	<div class="col-12 col-md-2">
		<div class="input-group">
			<input type="file" class="form-control"  name="pp_photo" >									
		</div>
		<span class="form-text text-muted">PP size Photo (Optional)</span>
	</div>

	<div class="col-12 col-md-2">
		<div class="input-group">
			<input type="file"  name="birth_certificate" class="form-control" >									
		</div>
		<span class="form-text text-muted">Birth Certificate (Optional)</span>
	</div>
	<div class="col-12 col-md-2">
		<div class="input-group">
			<input type="file" class="form-control"  name="transfer_certificate"  >									
		</div>
		<span class="form-text text-muted">Transfer Certificate (Optional)</span>
	</div>
	<div class="col-12 col-md-2">
		<div class="input-group">
			<input type="file" class="form-control"  name="last_marksheet"  >									
		</div>
		<span class="form-text text-muted">Marksheet (Optional)</span>
	</div>
	
	
</div>
