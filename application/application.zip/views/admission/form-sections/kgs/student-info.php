<div class="kt-section">
	<div class="kt-section__body">
		<h3 class="kt-section__title kt-section__title-lg">Student Info:</h3>
				

		<div class="form-group row">
			
			<label class="col-3 col-form-label">Name</label>
			<div class="col-9 col-md-6 form-group-sub">
				<input name="first_name" class="form-control" type="text" value="" placeholder="Student Name">				
			</div>
		
		</div>

		<div class="form-group row">
			<label class="col-3 col-form-label">Date of Birth</label>
			<div class="col-6">								
				<div class="form-group row">						
				
					<div class="col-12 col-md-12 form-group-sub">
						<input name="dob_year_bs" class="form-control" type="text" value="" placeholder="Date of birth">						
					</div>
				</div>				
			</div>
		</div>

		<div class="form-group  from-group-last row">
			<label class="col-3 col-form-label">Gender *</label>
			<div class="col-9">
				<div class="kt-radio-inline">
					<label class="kt-radio">
						<input type="radio" name="gender" value="male"> Male
						<span></span>
					</label>
					<label class="kt-radio">
						<input type="radio"  name="gender"  value="female"> Female
						<span></span>
					</label>
					
				</div>
			</div>
		</div>

	</div>
</div>
