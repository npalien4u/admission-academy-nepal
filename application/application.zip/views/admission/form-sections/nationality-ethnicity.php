<div class="form-group form-group row">
	<label class="col-3 col-form-label">Ethnicity</label>
	<div class="col-4">
		<div class="input-group">
			<input name="nationality" type="text" class="form-control" placeholder="Nationality" >									
		</div>
		<span class="form-text text-muted">Nationality</span>
	</div>
	<div class="col-5">
		<div class="input-group">
			<input  name="mother_tongue" type="text" class="form-control" placeholder="Mother tongue" >									
		</div>
		<span class="form-text text-muted">Mother tongue</span>
	</div>
</div>
