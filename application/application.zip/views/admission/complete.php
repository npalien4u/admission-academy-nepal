<style>
.kt-error-v5 .kt-error_container .kt-error_title > h1 {  
    margin-top: 3rem;  
}
</style>
		<!-- begin:: Page -->
			<div class="kt-portlet kt-portlet--last kt-portlet--head-lg kt-portlet--responsive-mobile" style="height:550px">
		<div class="kt-grid kt-grid--ver kt-grid--root" >
			<div class="kt-grid__item kt-grid__item--fluid kt-grid  kt-error-v5" style="background-image: url(<?=base_url()?>/assets/media/error/bg3.jpg);">
				<div class="kt-error_container">
					<span class="kt-error_title">
						<h1>Thank you!</h1>
					</span>
					<p class="kt-error_subtitle">
						Your application has been received.
					</p>
					<p class="kt-error_description">
						We will contact you as 
						as soon possible.
					</p>
					
				</div>
			</div>
		</div>
</div>

		<!-- end:: Page -->
