<div class="kt-section kt-section--first">
	<div class="kt-section__body">
		
		<div class="form-group form-group row">
			<label class="col-3 col-form-label">Previous School</label>
			<div class="col-9">
				<div class="input-group">
					<input name="previous_school_name" type="text" class="form-control" placeholder="Previous School Name" >									
				</div>
			</div>
		</div>

	

	</div>
</div>
