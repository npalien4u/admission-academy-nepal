<div class="kt-section">
	<div class="kt-section__body">
		<h3 class="kt-section__title kt-section__title-lg">Student Info:</h3>
				

		<div class="form-group row">
			
			<label class="col-3 col-form-label">Name</label>
			<div class="col-9 form-group-sub">
				<input name="first_name" class="form-control" type="text" value="" placeholder="Student Name">				
			</div>
		
		</div>

	

	</div>
</div>
